using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Attack
{
    public float damage;
    public Damage_Type damage_type;
}
