using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogueComponentData<T> : ComponentData<T>
{
}
