using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileComponentData<T> : ComponentData<T> 
{
    
}
