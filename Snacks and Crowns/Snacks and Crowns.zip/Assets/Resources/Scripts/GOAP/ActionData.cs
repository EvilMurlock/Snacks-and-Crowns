using System.Collections;
using System.Collections.Generic;
using UnityEngine;



namespace GOAP
{
    public class ActionData
    {

    }
}