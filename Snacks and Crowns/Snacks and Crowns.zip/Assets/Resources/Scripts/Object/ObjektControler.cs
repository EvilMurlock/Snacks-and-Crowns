using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjektControler : MonoBehaviour
{

    
    void Start()
    {
        //Set up health and resistances
        //GetComponent<Damagable>();

    }
}
